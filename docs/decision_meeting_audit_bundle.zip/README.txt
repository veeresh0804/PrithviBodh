Spatial Block Audit — decision-meeting share bundle
=====================================================
Source dir (local, gitignored/DVC-tracked, NOT in git): data/labels/audit/
Packaged: 2026-10-06 (Asia/Kolkata) from files last written 2026-10-06 ~12:08–13:34 IST.
Sampling seed: 42 (uniform-random point placement; seed-42 streams for grid draw).
Repo code pointer: commit 52c496e4603cffb679084cd7c82fd310704935fb
  (2026-10-06 13:35:32 +0530). Repro/audit logic lives in the repo at that
  commit: geoeco/labels/grid.py, tests/test_labelling_buffer.py.
  (data/labels/audit/collect.py is a LOCAL helper only — not committed, not
  included here. The full grid skeleton geojson, overlap index and per-member
  geojsons are also local-only and NOT included; ask the audit author if needed.)

Files in this zip:
- audit_report.md (7466 bytes): full audit narrative, Parts A (current band
  design) + B (grid alternative), comparison table, recommendation, assumptions,
  plus a cell-count check reconciling 156 cells vs naive 144 (13th row is a
  42 m northern edge sliver).
- stats.json (1732 bytes): machine-readable summary — per-block counts, 5 km
  fine-cell counts, distance-to-centre proxy stats, GroupKFold feasibility,
  semivariogram verdict (MISSING inputs), class-columns pending note.
- block_counts_current.csv (82 bytes): per-block point counts, current skeleton
  (test B0 672 / B1 655 / B2 673; train B3 789 / B4 711; total 3500).
- block_counts_grid.csv (1400 bytes): per-cell-group counts for the grid design
  (2000 test + 1500 train over 48 test / 36 train cells + 72 buffer cells).
- fineblock_current.csv (2859 bytes): full table of 149 occupied 5 km fine cells
  in the current design (1–41 pts/cell; 62 distinct train-side cells).
- grid_cells.csv (8357 bytes): the 12x13 = 156 grid-cell layout (cell_id, col,
  row, side in test/train/buffer, x0/y0/x1/y1 bounds).
- maps_cells.png (166484 bytes): side-by-side map figure (left: current bands,
  right: grid with buffer).
- README.txt: this file.

Secret scan at packaging: grep (case-insensitive) for kaggle|api_key|secret|
password over ALL files in data/labels/audit/ (incl. members_grid/ and
collect.py) returned 0 matches — no credentials in the audit or this bundle.

Note: per-class placement tables are PENDING in both designs (labels empty by
project hard rule 1 — every class x block cell is UNVERIFIABLE until humans
label; post-labelling validate.py fills this).
