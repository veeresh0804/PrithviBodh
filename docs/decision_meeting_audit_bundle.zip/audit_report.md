# Spatial Block Audit — Hyderabad labelling (vs commit a7add67)

No files overwritten. Originals intact: `data/labels/hyd_sampling_skeleton.geojson`,
`members/`, `overlap_index.csv`. Everything new lives in `data/labels/audit/`
(local, gitignored like all `data/`). Code added (committed): `geoeco/labels/grid.py`,
`tests/test_labelling_buffer.py`, `data/labels/audit/collect.py` (local helper).

## PART A — audit of the current (band) design

### A1. Stratification source: there is none, by rule
`geoeco/labels/pipeline.py` imports only `numpy`, `protocol.CLASSES` (class
*names*, not a map), and the YAML loader. Grep for
`dynamic_world|worldcover|rasterio|earthengine|benchmark|crosswalk|suggest`
hits docstring statements of the prohibition plus the optional `--prelabel-train`
import (default OFF). **No stratum derives from DW, WorldCover, or any
classification product — verified in code, not by assertion.**
Consequence: point placement is uniform-random (seed 42) within each split's
fold region. True class stratification is impossible pre-labelling without a
class map, and the only available maps are forbidden for test design (hard
rule 2). Class balance is therefore checked post-labelling (`validate.py`
balance report, <5% top-up rule). Per-class placement targets: none exist.

### A2. Per-block counts (current skeleton, 3,500 pts)
| block | split | n |
|---|---|---|
| B0 | test | 672 |
| B1 | test | 655 |
| B2 | test | 673 |
| B3 | train | 789 |
| B4 | train | 711 |
Per-class columns: **pending — labels are empty by hard rule 1.** Every class
in every block is therefore flagged UNVERIFIABLE (cannot confirm ≥100 test
points per class until humans label). Post-labelling, `validate.py` fills this.
Fine grid: 149 occupied 5 km cells, 1–41 pts/cell (full table:
`audit/fineblock_current.csv`; train-side distinct fine cells: 62).

### A3. What test-in-B0–B2 / train-in-B3–B4 implies
- **Area:** test bands cover 60% of the AOI, train bands 40% (bands are equal
  0.112° longitude slices; `train_area_share: 0.4` in `audit/stats.json`).
- **Regime (proxy: distance to city centre 17.38N 78.48E — no imagery needed,
  no benchmark touched):** test mean 21.7 km, mean lon 78.37 (west of centre);
  train mean 24.3 km, mean lon 78.64 (east). The urban core (lon 78.48) falls in
  **test band B2**, so the training set never sees the densest built-up fabric,
  while the test set does. Training regime ≈ eastern periphery (Uppal/LB
  Nagar/Hayathnagar + rural east); test regime ≈ core + west (HITEC/Jubilee +
  lakes). Expect a train/test regime gap in `built_up` and `water` signatures.
- **Nearest-neighbour leakage:** minimum test–train point distance is **0.43 km**
  across the B2/B3 boundary. Adjacent-band points are near-duplicates
  (same lake fringe, same road), inflating test scores the same way random
  splits do (Kattenborn 2022).

### A4. 5-fold GroupKFold on training points: NO at block level
Train uses 2 distinct blocks (B3, B4) < 5 folds — `group_kfold_splits` raises
`ValueError: Need >= 5 distinct blocks, got 2` (reproduced). Feasible only on
`fine_block` (62 train-side cells). Any M1–M5 spatial-CV code grouping by `block`
will crash on this design.

### A5. Semivariogram range: CANNOT compute — inputs missing
`data/**/*.tif`: none. `data/raw/composites/`: does not exist. Needed: EE export
of post-monsoon NDVI, VH, elevation at 10 m over the AOI. Range not guessed;
5 km stays provisional (inside the 3–10 km config range).

## PART B — grid alternative (generated, originals untouched)

5 km square cells (config default, provisional), 12×13 = 156 cells, seeded
random assignment with one-cell 8-neighbourhood buffer: **48 test / 36 train /
72 buffer cells**. Uniform sampling inside assigned cells (seed 42 streams):
2,000 test + 1,500 train → `audit/hyd_sampling_skeleton_grid.geojson`
(ids `HYD-G-*`). Overlap 351 pts + member files A 1,284 / B 1,281 / C 1,286 in
`audit/members_grid/` + `audit/overlap_index_grid.csv` (same tested logic).
Guarantee holds: min test–train distance **5.03 km ≥ 5.0 km**.

|  | current bands | grid |
|---|---|---|
| test points | 2,000 (60% area) | 2,000 (32.5% area) |
| train points | 1,500 (40% area) | 1,500 (20.3% area) |
| unsampled (buffer) | 0% | 47.1% area, 0 points |
| min test–train dist | 0.43 km | 5.03 km |
| 5-fold GroupKFold (train) | NO (2 blocks) | YES (36 cells) |
| regime split | hard east/west, core excluded from train | interleaved island pattern; seed-42 draw still offsets means (test 20.0 km vs train 28.4 km from centre) — chance, not structure |
| per-class ≥100 test | unverifiable (both; pending labels) | unverifiable (both; pending labels) |
| test/Core coverage | core city always test | core split across sides |

Buffer gate (`tests/test_labelling_buffer.py`, 4 passed): grid passes;
violation fixture fails; shared-block fails; **current design fails**
(documents the 0.43 km finding in CI-runnable form).
Maps: `audit/maps_cells.png` (left bands, right grid).

## Recommendation: adopt the grid design
1. It is the only design of the two on which the project's own 5-fold
   GroupKFold runs (NFR/DoD requirement; current B-level split crashes it).
2. The buffer (5.03 km verified) removes the 0.43 km near-duplicate leakage the
   current boundary creates — the exact inflation Kattenborn 2022 warns about.
3. Cost is explicit: 47% of AOI unsampled and a seed-dependent regime offset
   that must be re-checked per draw (re-run `collect.py`; reject draws with
   worse offset). Interleaving also means labellers travel more — acceptable
   since labelling is photo-interpretation, not fieldwork.
If the team prefers bands for labelling convenience, minimum fix: move to
fine-block groups for CV AND insert an empty guard band around B2/B3 — but that
is just the grid design with extra steps.

## Assumptions / missing / unverified
- Assumed: equal longitude bands were intended as B0–B4 (config gives a size
  range, not a layout); 5 km cell and 48/36 quotas documented above (quotas are
  audit-CLI defaults, not config — flagged, not hidden).
- Missing: S2/S1/DEM exports (A5, QGIS S2 layer, prelabel inputs), SoI boundary,
  all human labels (both designs' class tables pending).
- Unverified: `.qgz` files open cleanly in desktop QGIS (XML+zips validated in
  tests only); grid regime offset assessed by distance proxy only.
- Team decision required: adopt grid (replace skeleton via a follow-up task)
  or keep bands. Nothing merged or replaced here.

## Seed acceptance (pre-registered rule; seed 42 verdict: REJECT)

Rule: `configs/labels/labelling.yaml` -> `seed_acceptance` block. Checker:
`geoeco/labels/seed_check.py` (`check_seed_acceptance(skeleton_geojson)` +
CLI `python -m geoeco.labels.seed_check --skeleton <path>`; exit 2 names the
failing gates). Tests: `tests/test_seed_check.py` (3 passed: balanced passes,
offset fails, core-missing fails). Proxy table reuses
`data/labels/audit/collect.py` `summarize`/`hav`, so numbers below are exactly
the audit-A3 numbers. Seeds are chosen by covariate balance, NEVER by model
accuracy; the config seed is shown for traceability only.

Gates (all must pass; each choice documented in labelling.yaml comments):
1. `core_both_sides`: each split places >= 1 point within 10.0 km of the core
   point (17.38N 78.48E). Radius = 2x cell width (core cell + buffer ring +
   nearest opposite-side cell); an 8-neighbour-cell gate would be
   unsatisfiable because the design buffers opposite sides apart. Core cell
   id (diagnostic, `grid.build_cells` geometry): `g05_06`.
2. `mean_dist_gap`: |mean_dist_test - mean_dist_train| <= 5.0 km (one cell /
   buffer distance; larger = systematic regime shift). Pilot scan of 8 draws:
   gaps 1.4-10.9 km, ~25% pass — bites but satisfiable.
3. `lon_band_span`: AOI longitude split into 5 equal bands (B0-B4 width); each
   side spans >= 4 bands (>= 1 pt each). Catches hard east/west splits (band
   design spans 3 test / 2 train); all 8 pilot grid draws span >= 4.

Seed-42 grid verdict (`hyd_sampling_skeleton_grid.geojson`), checker output:
| split | n | mean_dist_km | mean_lon | mean_lat |
|---|---|---|---|---|
| test | 2000 | 19.99 | 78.566 | 17.404 |
| train | 1500 | 28.38 | 78.351 | 17.36 |
- `mean_dist_gap`: |19.99 - 28.38| = 8.39 km > 5.0 km — FAIL.
- `core_both_sides`: within 10 km test=344 train=0 (train minimum distance
  14.88 km; core cell g05_06 is buffer on this draw, its 8-neighbourhood holds
  6 test cells and 0 train) — FAIL.
- `lon_band_span`: test 5 bands [0,1,2,3,4], train 4 bands [0,1,2,4]
  (band 3, 78.536-78.648, empty on train side) — PASS.
- VERDICT: REJECT (failing gates: core_both_sides, mean_dist_gap), exit 2.
Next: draw a new grid seed and accept it only through this checker; do not
re-tune thresholds to rescue seed 42.

## Cell-count check (156 cells vs naive 144)

Question: 48 + 36 + 72 = 156 cells, but a 60×60 km AOI at 5 km "should" be
12×12 = 144. Recomputed from `configs/aoi/hyderabad.yaml`
`bounds_wgs84 = [78.20, 17.11, 78.76, 17.65]` with `grid.py:build_cells`
exact formula (`dlat = 5/111.19`, `dlon = 5/(111.32·cos(17.38°))`,
`ceil` per axis, clamp to bounds):

- `cos(17.38°) ≈ 0.95434` → `dlon = 5/106.23765 ≈ 0.04706°`,
  `dlat = 5/111.19 ≈ 0.04497°`.
- Columns: lon span `0.56° / 0.04706 ≈ 11.899` → `ceil = 12`.
- Rows: lat span `0.54° / 0.04497 ≈ 12.009` → `ceil = 13`
  (a hair over 12, so the 13th row exists as an edge sliver).
- Total `12 × 13 = 156` = 48 test + 36 train + 72 buffer. ✓ reconciles.
- Sliver confirmed in `grid_cells.csv`: every row-12 cell has
  `y0 = 17.64962, y1 = 17.65` (clamped to `maxlat`), i.e. `0.00038°`
  ≈ 42 m tall — a thin northern strip, not a full 5 km row.

## Addendum 2026-10-06 � zoned seed 6 PROMOTED (team decision)
- Canonical data/labels/* regenerated zoned (seed 6, quotas core 4/3 mid 23/17 far 21/16); seed-5 artefacts in audit/superseded_seed5/. Checker ACCEPT on promoted file (gap 1.05, core 177/123 under 5pct gate, bands 5/5, min dist 5.055). Members 1269/1297/1286, overlap 352. Checksum + 3-cell caveat in docs/seed_log.md. Guide map: audit/maps_zoned_seed6.png.

